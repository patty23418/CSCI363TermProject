﻿namespace CSCI363Project
{
    partial class SettingsPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsPage));
            panel1 = new Panel();
            pictureBox13 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox11 = new PictureBox();
            dateTimePicker1 = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            pictureBox5 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            panel3 = new Panel();
            label3 = new Label();
            label11 = new Label();
            label12 = new Label();
            checkedListBox1 = new CheckedListBox();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Location = new Point(-1, 27);
            panel1.Name = "panel1";
            panel1.Size = new Size(444, 2);
            panel1.TabIndex = 24;
            // 
            // pictureBox13
            // 
            pictureBox13.Location = new Point(404, 1);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(28, 21);
            pictureBox13.TabIndex = 23;
            pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Location = new Point(333, 1);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(28, 21);
            pictureBox12.TabIndex = 22;
            pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Location = new Point(370, 1);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(28, 21);
            pictureBox11.TabIndex = 21;
            pictureBox11.TabStop = false;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Segoe UI", 7F);
            dateTimePicker1.Location = new Point(-1, 1);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(175, 20);
            dateTimePicker1.TabIndex = 20;
            dateTimePicker1.Value = new DateTime(2024, 10, 23, 14, 0, 25, 0);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F);
            label1.Location = new Point(12, 32);
            label1.Name = "label1";
            label1.Size = new Size(218, 32);
            label1.TabIndex = 28;
            label1.Text = "Update Application";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(8, 293);
            label2.Name = "label2";
            label2.Size = new Size(139, 21);
            label2.TabIndex = 29;
            label2.Text = "Application Modes";
            // 
            // panel2
            // 
            panel2.Location = new Point(-1, 283);
            panel2.Name = "panel2";
            panel2.Size = new Size(444, 2);
            panel2.TabIndex = 25;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(103, 86);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(211, 151);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 30;
            pictureBox5.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Location = new Point(333, 325);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(42, 37);
            pictureBox7.TabIndex = 32;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Location = new Point(141, 329);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(50, 33);
            pictureBox8.TabIndex = 33;
            pictureBox8.TabStop = false;
            // 
            // panel3
            // 
            panel3.Location = new Point(-1, 373);
            panel3.Name = "panel3";
            panel3.Size = new Size(444, 2);
            panel3.TabIndex = 26;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.Location = new Point(12, 378);
            label3.Name = "label3";
            label3.Size = new Size(179, 21);
            label3.TabIndex = 34;
            label3.Text = "Enable/Disable Features:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F);
            label11.Location = new Point(31, 329);
            label11.Name = "label11";
            label11.Size = new Size(71, 21);
            label11.TabIndex = 42;
            label11.Text = "Daytime:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F);
            label12.Location = new Point(240, 329);
            label12.Name = "label12";
            label12.Size = new Size(87, 21);
            label12.TabIndex = 43;
            label12.Text = "Night time:";
            // 
            // checkedListBox1
            // 
            checkedListBox1.BackColor = Color.White;
            checkedListBox1.Font = new Font("Segoe UI", 11F);
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "Start/Stop Engine", "Lock/Unlock Doors", "Windows", "Alarm", "GPS", "Add Driver", "Add Vehicle" });
            checkedListBox1.Location = new Point(12, 410);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(420, 158);
            checkedListBox1.TabIndex = 44;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(331, 588);
            button4.Name = "button4";
            button4.Size = new Size(100, 54);
            button4.TabIndex = 56;
            button4.Text = "Settings";
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(225, 588);
            button3.Name = "button3";
            button3.Size = new Size(100, 54);
            button3.TabIndex = 55;
            button3.Text = "Controls";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(119, 588);
            button2.Name = "button2";
            button2.Size = new Size(100, 54);
            button2.TabIndex = 54;
            button2.Text = "Car Info";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackColor = Color.Transparent;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(14, 588);
            button1.Name = "button1";
            button1.Size = new Size(100, 54);
            button1.TabIndex = 53;
            button1.Text = "Main";
            button1.UseVisualStyleBackColor = false;
            // 
            // SettingsPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(443, 654);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(checkedListBox1);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label3);
            Controls.Add(panel3);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox5);
            Controls.Add(panel2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox11);
            Controls.Add(dateTimePicker1);
            Name = "SettingsPage";
            Text = "SettingsPage";
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private PictureBox pictureBox13;
        private PictureBox pictureBox12;
        private PictureBox pictureBox11;
        private DateTimePicker dateTimePicker1;
        private Label label1;
        private Label label2;
        private Panel panel2;
        private PictureBox pictureBox5;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private Panel panel3;
        private Label label3;
        private Label label11;
        private Label label12;
        private CheckedListBox checkedListBox1;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
    }
}